--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5beta1
-- Dumped by pg_dump version 9.5beta1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.user_authorities DROP CONSTRAINT user_authorities_authority_id_fkey;
DROP INDEX public.ix_username;
DROP INDEX public.ix_unq_auth_value;
DROP INDEX public.ix_auth_username;
DROP INDEX public.fk_authorities;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.cab DROP CONSTRAINT cab_pkey;
ALTER TABLE ONLY public.authority DROP CONSTRAINT authority_pkey;
DROP TABLE public.users;
DROP TABLE public.user_authorities;
DROP TABLE public.cab;
DROP TABLE public.authority;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: authority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE authority (
    authority_id integer NOT NULL,
    value character varying(50) NOT NULL
);


ALTER TABLE authority OWNER TO postgres;

--
-- Name: cab; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cab (
    id integer NOT NULL,
    vehicle_model character varying(100) NOT NULL
);


ALTER TABLE cab OWNER TO postgres;

--
-- Name: user_authorities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE user_authorities (
    user_id integer NOT NULL,
    authority_id integer NOT NULL
);


ALTER TABLE user_authorities OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(50) NOT NULL,
    enabled integer NOT NULL
);


ALTER TABLE users OWNER TO postgres;

--
-- Data for Name: authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2382.dat

--
-- Data for Name: cab; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2385.dat

--
-- Data for Name: user_authorities; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2384.dat

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2383.dat

--
-- Name: authority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY authority
    ADD CONSTRAINT authority_pkey PRIMARY KEY (authority_id);


--
-- Name: cab_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cab
    ADD CONSTRAINT cab_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: fk_authorities; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fk_authorities ON user_authorities USING btree (authority_id);


--
-- Name: ix_auth_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_auth_username ON user_authorities USING btree (user_id, authority_id);


--
-- Name: ix_unq_auth_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_unq_auth_value ON authority USING btree (value);


--
-- Name: ix_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_username ON users USING btree (username);


--
-- Name: user_authorities_authority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_authorities
    ADD CONSTRAINT user_authorities_authority_id_fkey FOREIGN KEY (authority_id) REFERENCES authority(authority_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

